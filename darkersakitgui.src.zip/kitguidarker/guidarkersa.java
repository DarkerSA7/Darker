/*     */ package kitguidarker;
/*     */ 
/*     */ import com.earth2me.essentials.CommandSource;
/*     */ import com.earth2me.essentials.Essentials;
/*     */ import com.earth2me.essentials.MetaItemStack;
/*     */ import com.earth2me.essentials.User;
/*     */ import com.earth2me.essentials.textreader.KeywordReplacer;
/*     */ import com.earth2me.essentials.textreader.SimpleTextInput;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.ess3.api.IItemDb;
/*     */ import net.ess3.api.ISettings;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryAction;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class guidarkersa extends JavaPlugin
/*     */   implements Listener
/*     */ {
/*  35 */   List<String> kits = new ArrayList();
/*  36 */   Essentials ess = null;
/*     */ 
/*     */   public void onEnable()
/*     */   {
/*  40 */     getServer().getPluginManager().registerEvents(this, this);
/*  41 */     getServer().getPluginManager().registerEvents(new Util(), this);
/*  42 */     this.ess = ((Essentials)getServer().getPluginManager().getPlugin("Essentials"));
/*  43 */     if ((this.ess != null) && 
/*  44 */       (this.ess.getConfig().isConfigurationSection("kits")))
/*  45 */       for (String s : this.ess.getConfig().getConfigurationSection("kits").getValues(false).keySet())
/*  46 */         this.kits.add(s);
/*     */   }
/*     */ 
/*     */   String strip(String s)
/*     */   {
/*  51 */     return ChatColor.stripColor(s);
/*     */   }
/*     */ 
/*     */   String cooldown(long t)
/*     */   {
/*  56 */     long days = t / 3600000L / 24L;
/*  57 */     long hours = t / 3600000L;
/*  58 */     long minutes = t / 60000L;
/*  59 */     long seconds = t / 1000L;
/*  60 */     if (t < 0L) {
/*  61 */       return "ERROR";
/*     */     }
/*  63 */     if (days >= 1L) {
/*  64 */       return String.format("%d day, %d hours, %d minutes, %d seconds", new Object[] { Long.valueOf(days), Long.valueOf(hours - days * 24L), Long.valueOf(minutes - hours * 60L), Long.valueOf(seconds - minutes * 60L) });
/*     */     }
/*  66 */     if (hours >= 1L) {
/*  67 */       return String.format("%d hours, %d minutes, %d seconds", new Object[] { Long.valueOf(hours), Long.valueOf(minutes - hours * 60L), Long.valueOf(seconds - minutes * 60L) });
/*     */     }
/*  69 */     if (minutes >= 1L) {
/*  70 */       return String.format("%d minutes, %d seconds", new Object[] { Long.valueOf(minutes), Long.valueOf(seconds - minutes * 60L) });
/*     */     }
/*  72 */     return String.format("%d seconds", new Object[] { Long.valueOf(seconds) });
/*     */   }
/*     */ 
/*     */   String time(long t)
/*     */   {
/*  77 */     long days = t / 3600000L / 24L;
/*  78 */     long hours = t / 3600000L;
/*  79 */     long minutes = t / 60000L;
/*  80 */     long seconds = t / 1000L;
/*  81 */     if (t < 0L) {
/*  82 */       return "ERROR";
/*     */     }
/*  84 */     if (days >= 1L) {
/*  85 */       return String.format("%d day(s)", new Object[] { Long.valueOf(days) });
/*     */     }
/*  87 */     if (hours >= 1L) {
/*  88 */       return String.format("%d hours", new Object[] { Long.valueOf(hours) });
/*     */     }
/*  90 */     if (minutes >= 1L) {
/*  91 */       return String.format("%d minutes", new Object[] { Long.valueOf(minutes) });
/*     */     }
/*  93 */     return String.format("%d seconds", new Object[] { Long.valueOf(seconds) });
/*     */   }
/*     */ 
/*     */   long kit(Player p, String name)
/*     */   {
/*  98 */     long lastUse = this.ess.getUser(p).getKitTimestamp(name.toLowerCase());
/*  99 */     if (!this.ess.getConfig().isConfigurationSection("kits." + name)) {
/* 100 */       return 0L;
/*     */     }
/* 102 */     long delay = this.ess.getConfig().getConfigurationSection("kits." + name).getLong("delay") * 1000L;
/* 103 */     if ((System.currentTimeMillis() >= lastUse + delay) || (!this.ess.getConfig().isConfigurationSection("kits." + name))) {
/* 104 */       return 0L;
/*     */     }
/* 106 */     return lastUse + delay - System.currentTimeMillis();
/*     */   }
/*     */   @EventHandler
/*     */   public void invClick(InventoryClickEvent e) {
/* 111 */     Player p = (Player)e.getWhoClicked();
/* 112 */     if ((e.getCurrentItem() == null) || (e.getCurrentItem().getType().equals(Material.AIR))) {
/* 113 */       return;
/*     */     }
/* 115 */     if (e.getInventory().getTitle().endsWith("§7 Kits"))
/*     */     {
/* 117 */       e.setCancelled(true);
/* 118 */       if (e.getAction().equals(InventoryAction.PICKUP_HALF))
/*     */       {
/* 120 */         int size = 0;
/* 121 */         ArrayList items = new ArrayList();
/* 122 */         String name = strip(e.getCurrentItem().getItemMeta().getDisplayName().split(" ")[0]);
/*     */         try
/*     */         {
/* 125 */           items = (ArrayList)this.ess.getConfig().getConfigurationSection("kits." + name).getValues(false);
/* 126 */           size = items.size();
/*     */         }
/*     */         catch (Exception localException1) {
/*     */         }
/*     */         do size++;
/* 131 */         while ((size == 0) || (size % 9 != 0));
/*     */ 
/* 133 */         Inventory inv = Bukkit.createInventory(null, size, "§7Kit Preview");
/*     */         try
/*     */         {
/* 136 */           SimpleTextInput input = new SimpleTextInput(items);
/* 137 */           KeywordReplacer output = new KeywordReplacer(input, new CommandSource(p), this.ess);
/* 138 */           boolean allowUnsafe = this.ess.getSettings().allowUnsafeEnchantments();
/* 139 */           for (String kitItem : output.getLines())
/*     */           {
/* 141 */             String[] parts = kitItem.split(" +");
/* 142 */             ItemStack parseStack = this.ess.getItemDb().get(parts[0], kitItem.split(" +").length > 1 ? Integer.parseInt(parts[1]) : 1);
/* 143 */             if (parseStack.getType() == Material.AIR)
/*     */               continue;
/* 145 */             MetaItemStack metaStack = new MetaItemStack(parseStack);
/* 146 */             if (parts.length > 2) {
/* 147 */               metaStack.parseStringMeta(null, allowUnsafe, parts, 2, this.ess);
/*     */             }
/* 149 */             inv.addItem(new ItemStack[] { metaStack.getItemStack() });
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (Exception e1)
/*     */         {
/* 155 */           e1.printStackTrace();
/*     */         }
/* 157 */         for (int i = 0; i < inv.getSize(); i++) {
/* 158 */           if (inv.getItem(i) == null) {
/* 159 */             inv.setItem(i, Util.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", new String[0]));
/*     */           }
/*     */         }
/* 162 */         p.closeInventory();
/* 163 */         p.openInventory(inv);
/* 164 */         return;
/*     */       }
/* 166 */       if (e.getCurrentItem().getDurability() == Util.Pane.GREEN.value())
/*     */       {
/* 168 */         p.performCommand("ekits " + strip(e.getCurrentItem().getItemMeta().getDisplayName().split(" ")[0]));
/* 169 */         p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0F, 1.0F);
/* 170 */         p.closeInventory();
/*     */       }
/*     */     }
/* 173 */     else if (e.getInventory().getTitle().equals("§7Kit Preview"))
/*     */     {
/* 175 */       e.setCancelled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void cmd(PlayerCommandPreprocessEvent e) {
/* 181 */     Player p = e.getPlayer();
/* 182 */     if ((e.getMessage().startsWith("/kit")) || (e.getMessage().equals("/kit")) || (e.getMessage().split(" ")[0].equals("/ekit")))
/*     */     {
/* 184 */       e.setCancelled(true);
/* 185 */       int size = this.kits.size();
/* 186 */       while ((size == 0) || (size % 9 != 0)) {
/* 187 */         size++;
/*     */       }
/* 189 */       p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1.0F, 1.0F);
/* 190 */       Inventory inv = getServer().createInventory(null, size, "§7Viewing §n" + this.kits.size() + "§7 Kits");
/* 191 */       for (String kit : this.kits) {
/* 192 */         if (p.hasPermission("essentials.kits." + kit))
/*     */         {
/* 194 */           if (kit(p, kit) > 0L)
/* 195 */             inv.setItem(inv.firstEmpty(), 
/* 196 */               Util.createItem(Material.STAINED_GLASS_PANE, 1, 1, "§6§n" + kit, new String[] { "", "§6§lKit Information:", 
/* 197 */               " §8§ §eCooldown §7" + time(this.ess.getConfig().getConfigurationSection(new StringBuilder("kits.").append(kit).toString()).getLong("delay") * 1000L), 
/* 198 */               " §8§ §eNumber of Items §7" + this.ess.getConfig().getConfigurationSection(new StringBuilder("kits.").append(kit).toString()).getList("items").size(), "", 
/* 199 */               "§6§l§nCOOLING DOWN", "§7Use again in §6" + cooldown(kit(p, kit)), "§7Click to recieve this kit." }));
/*     */           else {
/* 201 */             inv.setItem(inv.firstEmpty(), 
/* 202 */               Util.createItem(Material.STAINED_GLASS_PANE, 1, Util.Pane.GREEN.value(), "§a§n" + kit, new String[] { "", 
/* 203 */               "§6§lKit Information:", 
/* 204 */               " §8§ §eCooldown §7" + time(this.ess.getConfig().getConfigurationSection(new StringBuilder("kits.").append(kit).toString()).getLong("delay") * 1000L), 
/* 205 */               " §8§ §eNumber of Items §7" + this.ess.getConfig().getConfigurationSection(new StringBuilder("kits.").append(kit).toString()).getList("items").size(), "", 
/* 206 */               "§a§lUNLOCKED", "§7Click to recieve this kit." }));
/*     */           }
/*     */         }
/*     */         else {
/* 210 */           inv.setItem(inv.firstEmpty(), 
/* 211 */             Util.createItem(Material.STAINED_GLASS_PANE, 1, Util.Pane.RED.value(), "§c§n" + kit, new String[] { "", 
/* 212 */             "§8§ §cYou don't have permission to redeem this kit.", "", "§6§lKit Information:", 
/* 213 */             " §8§ §eCooldown §7" + time(this.ess.getConfig().getConfigurationSection(new StringBuilder("kits.").append(kit).toString()).getLong("delay") * 1000L), 
/* 214 */             " §8§ §eNumber of Items §7" + this.ess.getConfig().getConfigurationSection(new StringBuilder("kits.").append(kit).toString()).getList("items").size(), "", 
/* 215 */             "§c§lLOCKED", "§7unlock at shop.novamc.co", "§7Click to recieve this kit." }));
/*     */         }
/*     */       }
/* 218 */       p.openInventory(inv);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Om\Desktop\مجلد جديد\‏‏‏‏SetupServerPrivate - نسخة - نسخة\plugins\kitgui.jar
 * Qualified Name:     kitguidarker.guidarkersa
 * JD-Core Version:    0.6.0
 */
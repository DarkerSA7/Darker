/*     */ package kitguidarker;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.enchantments.EnchantmentTarget;
/*     */ import org.bukkit.enchantments.EnchantmentWrapper;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ 
/*     */ public class Util
/*     */   implements Listener
/*     */ {
/*     */   public static ItemStack createHead(String owner, String name, String[] lore)
/*     */   {
/*  22 */     ItemStack item = new ItemStack(Material.SKULL_ITEM, 1, 3);
/*  23 */     SkullMeta meta = (SkullMeta)item.getItemMeta();
/*  24 */     meta.setOwner(owner);
/*  25 */     meta.setDisplayName(name);
/*  26 */     List l = new ArrayList();
/*     */     String[] arrayOfString;
/*  28 */     int j = (arrayOfString = lore).length;
/*  29 */     for (int i = 0; i < j; i++) {
/*  30 */       String s = arrayOfString[i];
/*  31 */       l.add(s);
/*     */     }
/*  33 */     meta.setLore(l);
/*  34 */     item.setItemMeta(meta);
/*  35 */     return item;
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(Material mat, int amt, int durability, String name, List<String> lore) {
/*  39 */     ItemStack item = new ItemStack(mat, amt);
/*  40 */     ItemMeta meta = item.getItemMeta();
/*  41 */     meta.setDisplayName(name);
/*  42 */     meta.setLore(lore);
/*  43 */     if (durability != 0)
/*  44 */       item.setDurability((short)durability);
/*  45 */     item.setItemMeta(meta);
/*  46 */     return item;
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(Material mat, int amt, String name, List<String> lore) {
/*  50 */     return createItem(mat, amt, 0, name, lore);
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(Material mat, int amt, int durability, String name, String[] lore) {
/*  54 */     List l = new ArrayList();
/*     */     String[] arrayOfString;
/*  56 */     int j = (arrayOfString = lore).length;
/*  57 */     for (int i = 0; i < j; i++) {
/*  58 */       String s = arrayOfString[i];
/*  59 */       l.add(s);
/*     */     }
/*  61 */     return createItem(mat, amt, durability, name, l);
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(Material mat, int amt, String name, String[] lore) {
/*  65 */     return createItem(mat, amt, 0, name, lore);
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(Material mat, String name, String[] lore) {
/*  69 */     return createItem(mat, 1, 0, name, lore);
/*     */   }
/*     */ 
/*     */   public static void remove(Inventory inv, Material mat, int amt) {
/*  73 */     int amount = 0;
/*     */     ItemStack[] arrayOfItemStack;
/*  75 */     int j = (arrayOfItemStack = inv.getContents()).length;
/*  76 */     for (int i = 0; i < j; i++) {
/*  77 */       ItemStack item = arrayOfItemStack[i];
/*  78 */       if ((item != null) && (item.getType() == mat))
/*  79 */         amount += item.getAmount();
/*     */     }
/*  81 */     inv.remove(mat);
/*  82 */     if (amount > amt)
/*  83 */       inv.addItem(new ItemStack[] { new ItemStack(mat, amount - amt) });
/*     */   }
/*     */ 
/*     */   public static String caps(String string) {
/*  87 */     String[] list = string.split("_");
/*  88 */     String s = "";
/*     */     String[] arrayOfString1;
/*  90 */     int j = (arrayOfString1 = list).length;
/*  91 */     for (int i = 0; i < j; i++) {
/*  92 */       String st = arrayOfString1[i];
/*  93 */       s = String.valueOf(s) + st.substring(0, 1).toUpperCase() + st.substring(1).toLowerCase();
/*     */     }
/*  95 */     return s;
/*     */   }
/*     */ 
/*     */   public static boolean isInt(String s) {
/*     */     try {
/* 100 */       Integer.parseInt(s);
/* 101 */       return true; } catch (NumberFormatException numberFormatException) {
/*     */     }
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   public static String color(String s)
/*     */   {
/* 108 */     return ChatColor.translateAlternateColorCodes('&', s);
/*     */   }
/*     */ 
/*     */   public static List<String> color(List<String> list) {
/* 112 */     List colored = new ArrayList();
/* 113 */     for (String s : list)
/* 114 */       colored.add(color(s));
/* 115 */     return colored;
/*     */   }
/*     */ 
/*     */   public static Material getMaterial(String s) {
/* 119 */     if (Material.getMaterial(s) != null)
/* 120 */       return Material.getMaterial(s);
/* 121 */     if ((isInt(s)) && (Material.getMaterial(Integer.parseInt(s)) != null))
/* 122 */       return Material.getMaterial(Integer.parseInt(s));
/* 123 */     if (Material.matchMaterial(s) != null)
/* 124 */       return Material.matchMaterial(s);
/* 125 */     if (Material.valueOf(s.toUpperCase()) != null)
/* 126 */       return Material.valueOf(s.toUpperCase());
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   public static List<Integer> getBorder(int size) {
/* 131 */     switch (size) {
/*     */     case 54:
/* 133 */       return Arrays.asList(new Integer[] { 
/* 134 */         Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), 
/* 135 */         Integer.valueOf(17), Integer.valueOf(18), Integer.valueOf(26), Integer.valueOf(27), Integer.valueOf(35), Integer.valueOf(36), Integer.valueOf(44), Integer.valueOf(45), Integer.valueOf(46), Integer.valueOf(47), 
/* 136 */         Integer.valueOf(48), Integer.valueOf(49), Integer.valueOf(50), Integer.valueOf(51), Integer.valueOf(52), Integer.valueOf(53) });
/*     */     case 45:
/* 138 */       return Arrays.asList(new Integer[] { 
/* 139 */         Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), 
/* 140 */         Integer.valueOf(17), Integer.valueOf(18), Integer.valueOf(26), Integer.valueOf(27), Integer.valueOf(35), Integer.valueOf(36), Integer.valueOf(37), Integer.valueOf(38), Integer.valueOf(39), Integer.valueOf(40), 
/* 141 */         Integer.valueOf(41), Integer.valueOf(42), Integer.valueOf(43), Integer.valueOf(44) });
/*     */     case 36:
/* 143 */       return Arrays.asList(new Integer[] { 
/* 144 */         Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), 
/* 145 */         Integer.valueOf(17), Integer.valueOf(18), Integer.valueOf(26), Integer.valueOf(27), Integer.valueOf(28), Integer.valueOf(29), Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(33), 
/* 146 */         Integer.valueOf(34), Integer.valueOf(35) });
/*     */     case 27:
/* 148 */       return Arrays.asList(new Integer[] { 
/* 149 */         Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), 
/* 150 */         Integer.valueOf(17), Integer.valueOf(18), Integer.valueOf(19), Integer.valueOf(20), Integer.valueOf(21), Integer.valueOf(22), Integer.valueOf(23), Integer.valueOf(24), Integer.valueOf(25), Integer.valueOf(26) });
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */   public static int getTotalExperience(Player player) {
/* 156 */     int exp = Math.round(getExpAtLevel(player.getLevel()) * player.getExp());
/* 157 */     int currentLevel = player.getLevel();
/* 158 */     while (currentLevel > 0) {
/* 159 */       currentLevel--;
/* 160 */       exp += getExpAtLevel(currentLevel);
/*     */     }
/* 162 */     if (exp < 0)
/* 163 */       exp = 2147483647;
/* 164 */     return exp;
/*     */   }
/*     */ 
/*     */   public static int getExpAtLevel(int level) {
/* 168 */     if (level > 29)
/* 169 */       return 62 + (level - 30) * 7;
/* 170 */     if (level > 15)
/* 171 */       return 17 + (level - 15) * 3;
/* 172 */     return 17;
/*     */   }
/*     */ 
/*     */   public static boolean isArmour(Material m) {
/* 176 */     return Enchantment.PROTECTION_ENVIRONMENTAL.canEnchantItem(new ItemStack(m));
/*     */   }
/*     */ 
/*     */   public static boolean isDiamond(Material m) {
/* 180 */     return m.toString().contains("DIAMOND");
/*     */   }
/*     */ 
/*     */   public static boolean isGold(Material m) {
/* 184 */     return m.toString().contains("GOLD");
/*     */   }
/*     */ 
/*     */   public static boolean isIron(Material m) {
/* 188 */     return m.toString().contains("IRON");
/*     */   }
/*     */ 
/*     */   public static boolean isLeather(Material m) {
/* 192 */     return m.toString().contains("LEATHER");
/*     */   }
/*     */ 
/*     */   public static boolean isChain(Material m) {
/* 196 */     return m.toString().contains("CHAIN");
/*     */   }
/*     */ 
/*     */   public static boolean isSword(Material m) {
/* 200 */     return m.toString().contains("SWORD");
/*     */   }
/*     */ 
/*     */   public static boolean isAxe(Material m) {
/* 204 */     return m.toString().endsWith("_AXE");
/*     */   }
/*     */ 
/*     */   public static boolean isPickaxe(Material m) {
/* 208 */     return m.toString().contains("PICKAXE");
/*     */   }
/*     */ 
/*     */   public static boolean isWeapon(Material m) {
/* 212 */     return Enchantment.DAMAGE_ALL.canEnchantItem(new ItemStack(m));
/*     */   }
/*     */ 
/*     */   public static boolean isTool(Material m) {
/* 216 */     return Enchantment.DIG_SPEED.canEnchantItem(new ItemStack(m));
/*     */   }
/*     */ 
/*     */   public static String getName(EntityType e) {
/* 220 */     if (e.equals(EntityType.PIG_ZOMBIE))
/* 221 */       return "Zombie Pigman";
/* 222 */     if (!e.toString().contains("_"))
/* 223 */       return String.valueOf(e.toString().substring(0, 1).toUpperCase()) + e.toString().substring(1).toLowerCase();
/* 224 */     String[] split = e.toString().split("_");
/* 225 */     String name = "";
/*     */     String[] arrayOfString1;
/* 227 */     int j = (arrayOfString1 = split).length;
/* 228 */     for (int i = 0; i < j; i++) {
/* 229 */       String s = arrayOfString1[i];
/* 230 */       name = String.valueOf(name) + s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase() + " ";
/*     */     }
/* 232 */     return name.trim();
/*     */   }
/*     */ 
/*     */   public static EntityType getEntity(String e) {
/* 236 */     if (e.equalsIgnoreCase("Zombie Pigman"))
/* 237 */       return EntityType.PIG_ZOMBIE;
/* 238 */     e = e.replaceAll(" ", "_");
/* 239 */     if (!e.contains("_"))
/* 240 */       return EntityType.valueOf(e.toUpperCase());
/* 241 */     String[] split = e.toString().split(" ");
/* 242 */     String name = "";
/*     */     String[] arrayOfString1;
/* 244 */     int j = (arrayOfString1 = split).length;
/* 245 */     for (int i = 0; i < j; i++) {
/* 246 */       String s = arrayOfString1[i];
/* 247 */       name = String.valueOf(name) + s.toUpperCase() + "_";
/*     */     }
/* 249 */     return EntityType.valueOf(name.substring(0, name.length() - 1));
/*     */   }
/*     */ 
/*     */   public static class EnchantGlow extends EnchantmentWrapper {
/* 282 */     private static Enchantment glow = null;
/*     */     private String name;
/*     */ 
/*     */     public static void addGlow(ItemStack itemstack) {
/* 287 */       itemstack.addEnchantment(getGlow(), 1);
/*     */     }
/*     */ 
/*     */     public static Enchantment getGlow() {
/* 291 */       if (glow != null)
/* 292 */         return glow;
/* 293 */       Field field = null;
/*     */       try {
/* 295 */         field = Enchantment.class.getDeclaredField("acceptingNew");
/*     */       } catch (java.lang.SecurityException e) {
/* 297 */         e.printStackTrace();
/* 298 */         return glow;
/*     */       }
/* 300 */       field.setAccessible(true);
/*     */       try {
/* 302 */         field.set(null, Boolean.valueOf(true));
/*     */       } catch (java.lang.IllegalAccessException e) {
/* 304 */         e.printStackTrace();
/*     */       }
/*     */       try {
/* 307 */         glow = new EnchantGlow(Enchantment.values().length + 100);
/*     */       } catch (Exception e) {
/* 309 */         glow = Enchantment.getByName("Glow");
/*     */       }
/* 311 */       if (Enchantment.getByName("Glow") == null)
/* 312 */         Enchantment.registerEnchantment(glow);
/* 313 */       return glow;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 317 */       return this.name;
/*     */     }
/*     */ 
/*     */     public Enchantment getEnchantment() {
/* 321 */       return Enchantment.getByName("Glow");
/*     */     }
/*     */ 
/*     */     public int getMaxLevel() {
/* 325 */       return 1;
/*     */     }
/*     */ 
/*     */     public int getStartLevel() {
/* 329 */       return 1;
/*     */     }
/*     */ 
/*     */     public EnchantmentTarget getItemTarget() {
/* 333 */       return EnchantmentTarget.ALL;
/*     */     }
/*     */ 
/*     */     public boolean canEnchantItem(ItemStack item) {
/* 337 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean conflictsWith(Enchantment other) {
/* 341 */       return false;
/*     */     }
/*     */ 
/*     */     public EnchantGlow(int i) {
/* 345 */       super();
/* 346 */       this.name = "Glow";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum Pane
/*     */   {
/* 253 */     WHITE(0), 
/* 254 */     ORANGE(1), 
/* 255 */     MAGENTA(2), 
/* 256 */     LIGHT_BLUE(3), 
/* 257 */     YELLOW(4), 
/* 258 */     LIME(5), 
/* 259 */     PINK(6), 
/* 260 */     GRAY(7), 
/* 261 */     LIGHT_GRAY(8), 
/* 262 */     CYAN(9), 
/* 263 */     PURPLE(10), 
/* 264 */     BLUE(11), 
/* 265 */     BROWN(12), 
/* 266 */     GREEN(13), 
/* 267 */     RED(14), 
/* 268 */     BLACK(15);
/*     */ 
/*     */     private int value;
/*     */ 
/* 273 */     private Pane(int value) { this.value = value; }
/*     */ 
/*     */     public int value()
/*     */     {
/* 277 */       return this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Om\Desktop\مجلد جديد\‏‏‏‏SetupServerPrivate - نسخة - نسخة\plugins\kitgui.jar
 * Qualified Name:     kitguidarker.Util
 * JD-Core Version:    0.6.0
 */